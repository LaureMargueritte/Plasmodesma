#!/usr/bin/env python 
 # encoding: utf-8


"""
Created by Marc-André on 2011-03-20.
Copyright (c) 2011 IGBMC. All rights reserved.
"""


def main():
    pass


if __name__ == '__main__':
    main()

